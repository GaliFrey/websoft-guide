﻿"META:NAMESPACE:server_restart_info";

var date = Date();
var token = Random(1000000000000000, 9999999999999999);