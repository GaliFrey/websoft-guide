﻿try {
    RegisterCodeLibrary('./server_restart_info/store.js');
    alert('Модуль server_restart_info успешно загружен');
} catch (err) {
    alert('При загрузке модуля server_restart_info произошла ошибка ' + err)
}